package com.example.ejerciciorestaurante

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
